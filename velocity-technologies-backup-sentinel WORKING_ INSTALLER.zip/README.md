# Velocity Backup Sentinel

A robust, modern dashboard for configuring, scheduling, and monitoring automated backups from various sources like SFTP, cPanel, Cisco, and Ubiquiti devices.

## Installation & Setup (Linux/macOS)

This application can be installed and run with a single command using the provided installer script.

### Prerequisites

-   **Node.js & npm**: You must have Node.js (version 16 or newer) and npm installed. You can download them from [nodejs.org](https://nodejs.org/).

### 1. Run the Installer

Open your terminal, navigate to the project directory, give the script execution permissions, and then run it:

```bash
chmod +x installer.sh
./installer.sh
```

The script will guide you through the following steps:
1.  **Dependency Check**: Verifies that Node.js and npm are installed.
2.  **API Key Configuration**: You will be prompted to enter your Google Gemini API Key. This is required for the "Log Analysis" feature. The key is saved locally in a `.env` file and is not committed to version control.
3.  **Install Dependencies**: Downloads all the required `npm` packages.
4.  **Build Application**: Compiles the React/TypeScript application into static files ready for production.

### 2. Start the Application

Once the installation is complete, you can start the web server with the following command:

```bash
npm start
```

This will launch a local server (usually on port 3000). You can now access the application by opening your web browser and navigating to:

**http://localhost:3000**

### Default Login

-   **Username**: `admin`
-   **Password**: `password`
