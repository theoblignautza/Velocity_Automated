
export type ViewType = 'dashboard' | 'jobs' | 'files' | 'scheduler' | 'settings';

export enum JobType {
  SFTP = 'SFTP',
  CPANEL = 'cPanel',
  CISCO = 'Cisco Router',
  UBIQUITI = 'Ubiquiti UniFi',
}

export interface BackupJob {
  id: string;
  name: string;
  type: JobType;
  host: string;
  port: number;
  lastBackup: string;
  status: 'Success' | 'Failed' | 'Pending';
}

export interface BackupFile {
  id: string;
  filename: string;
  size: string;
  created: string;
  job: string;
}

export interface Schedule {
  id: string;
  jobId: string;
  nextRun: string;
}

export interface CpuData {
  time: string;
  usage: number;
}
