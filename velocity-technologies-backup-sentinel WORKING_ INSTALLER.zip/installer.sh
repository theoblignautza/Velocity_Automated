#!/bin/bash

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}Starting Velocity Backup Sentinel Installer...${NC}"
echo "------------------------------------------------"

# --- Dependency Check ---
echo -e "${YELLOW}Step 1: Checking for dependencies (Node.js & npm)...${NC}"
if ! command -v node &> /dev/null
then
    echo -e "${RED}Node.js could not be found.${NC}"
    echo "Please install Node.js (which includes npm) to continue."
    echo "You can download it from https://nodejs.org/"
    exit 1
fi

if ! command -v npm &> /dev/null
then
    echo -e "${RED}npm could not be found.${NC}"
    echo "Please install npm (usually included with Node.js) to continue."
    exit 1
fi

echo -e "${GREEN}Dependencies found!${NC}"
echo "Node version: $(node -v)"
echo "npm version: $(npm -v)"
echo "------------------------------------------------"

# --- API Key Configuration ---
echo -e "${YELLOW}Step 2: Configuring API Key...${NC}"
if [ ! -f .env ]; then
    echo "Please enter your Google Gemini API Key for the Log Analysis feature:"
    read -p "> " apiKey
    echo "VITE_API_KEY=${apiKey}" > .env
    echo ".env file created with your API key."
else
    echo ".env file already exists. Skipping API key setup."
fi
echo "------------------------------------------------"

# --- Install Dependencies ---
echo -e "${YELLOW}Step 3: Installing project dependencies with npm...${NC}"
echo "This may take a few moments."
if npm install; then
    echo -e "${GREEN}Dependencies installed successfully!${NC}"
else
    echo -e "${RED}Failed to install dependencies. Please check for errors above.${NC}"
    exit 1
fi
echo "------------------------------------------------"

# --- Build Application ---
echo -e "${YELLOW}Step 4: Building the application for production...${NC}"
if npm run build; then
    echo -e "${GREEN}Application built successfully!${NC}"
    echo "Static files are located in the 'dist' directory."
else
    echo -e "${RED}Failed to build the application. Please check for errors above.${NC}"
    exit 1
fi
echo "------------------------------------------------"

# --- Final Instructions ---
echo -e "${GREEN}Installation Complete!${NC}"
echo
echo "To run the application, use the following command:"
echo -e "${YELLOW}npm start${NC}"
echo
echo "This will start a local server, and you can access the dashboard in your browser."
echo "The application will typically be available at http://localhost:3000"
echo "------------------------------------------------"
