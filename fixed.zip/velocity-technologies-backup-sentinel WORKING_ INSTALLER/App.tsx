
import React, { useState, useEffect, useCallback } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import BackupJobs from './components/BackupJobs';
import FileManager from './components/FileManager';
import Scheduler from './components/Scheduler';
import Settings from './components/Settings';
import type { ViewType, CpuData } from './types';
import GlobalBackupNotification from './components/GlobalBackupNotification';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [logoSrc, setLogoSrc] = useState<string | null>(null);
  const [cpuData, setCpuData] = useState<CpuData[]>([]);

  // Lifted state for global access
  const [isBackupRunning, setIsBackupRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>(['[SYSTEM] Initializing Sentinel Core...']);

  const addLog = useCallback((message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev.slice(-100), `[${timestamp}] ${message}`]);
  }, []);
  
  // Initialize logs on authentication
  useEffect(() => {
    if (isAuthenticated && logs.length < 2) {
      addLog('[SYSTEM] Connection established.');
      addLog('[INFO] Monitoring for scheduled jobs.');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);


  useEffect(() => {
    const storedAuth = localStorage.getItem('isAuthenticated');
    if (storedAuth === 'true') {
      setIsAuthenticated(true);
    }
    const storedLogo = localStorage.getItem('appLogo');
    if (storedLogo) {
      setLogoSrc(storedLogo);
    }
  }, []);

  // Effect to continuously update CPU data in the background after login
  useEffect(() => {
    if (!isAuthenticated) return;

    const interval = setInterval(() => {
      setCpuData(prevData => {
        const lastUsage = prevData.length > 0 ? prevData[prevData.length - 1].usage : 50;
        const change = (Math.random() - 0.5) * 15; // More gradual change
        let newUsage = lastUsage + change;
        newUsage = Math.max(5, Math.min(95, newUsage)); // Keep it within a realistic bound
        // Occasional random spike
        if (Math.random() > 0.95) {
            newUsage = Math.random() * 50 + 50;
        }

        const now = new Date();
        const newPoint = {
          time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          usage: Math.round(newUsage),
        };
        const newData = [...prevData, newPoint];
        // Keep a history of the last 100 data points
        return newData.length > 100 ? newData.slice(newData.length - 100) : newData;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isAuthenticated]);

  const handleRunBackup = () => {
    if (isBackupRunning) return;
    setIsBackupRunning(true);
    addLog('[ACTION] Manual backup process initiated by user.');
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      addLog(`[SFTP_JOB_1] Downloading files... ${progress}%`);
      if (progress >= 100) {
        clearInterval(interval);
        addLog('[SFTP_JOB_1] Download complete.');
        addLog('[ARCHIVER] Compressing backup file: backup_20240726_1400.tar.gz');
        setTimeout(() => {
            addLog('[SUCCESS] Backup completed successfully.');
            setIsBackupRunning(false);
        }, 1000);
      }
    }, 500);
  };

  const handleLoginSuccess = () => {
    localStorage.setItem('isAuthenticated', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    setIsAuthenticated(false);
    setCurrentView('dashboard');
    setCpuData([]); // Clear CPU data on logout
    setLogs(['[SYSTEM] Initializing Sentinel Core...']);
  };
  
  const handleLogoChange = (newLogo: string) => {
    localStorage.setItem('appLogo', newLogo);
    setLogoSrc(newLogo);
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard 
                  cpuData={cpuData} 
                  isBackupRunning={isBackupRunning}
                  logs={logs}
                  handleRunBackup={handleRunBackup}
                />;
      case 'jobs':
        return <BackupJobs />;
      case 'files':
        return <FileManager />;
      case 'scheduler':
        return <Scheduler />;
      case 'settings':
        return <Settings onLogoChange={handleLogoChange} />;
      default:
        return <Dashboard 
                  cpuData={cpuData} 
                  isBackupRunning={isBackupRunning}
                  logs={logs}
                  handleRunBackup={handleRunBackup}
                />;
    }
  };

  if (!isAuthenticated) {
    return <Login onLoginSuccess={handleLoginSuccess} logoSrc={logoSrc} />;
  }

  return (
    <div className="bg-gray-900 text-green-400 min-h-screen flex selection:bg-green-900 selection:text-green-300">
      <Sidebar currentView={currentView} setCurrentView={setCurrentView} logoSrc={logoSrc} />
      <div className="flex-1 flex flex-col">
        <Header username="admin" onLogout={handleLogout} />
        <GlobalBackupNotification isBackupRunning={isBackupRunning} />
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default App;
