
import React, { useState } from 'react';
import LogViewer from './LogViewer';
import CpuChart from './CpuChart';
import { getGeminiLogSummary } from '../services/geminiService';
import type { CpuData } from '../types';

const StatusCard: React.FC<{ title: string; value: string; statusColor?: string }> = ({ title, value, statusColor = 'text-green-400' }) => (
  <div className="bg-gray-950/30 p-4 border border-green-500/20 backdrop-blur-sm">
    <h3 className="text-sm text-gray-400 uppercase tracking-wider">{title}</h3>
    <p className={`text-2xl font-bold ${statusColor}`}>{value}</p>
  </div>
);

interface DashboardProps {
  cpuData: CpuData[];
  isBackupRunning: boolean;
  logs: string[];
  handleRunBackup: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ cpuData, isBackupRunning, logs, handleRunBackup }) => {
  const [summary, setSummary] = useState('Awaiting log data...');
  const [isSummaryLoading, setIsSummaryLoading] = useState(false);
  
  const handleAnalyzeLogs = async () => {
    setIsSummaryLoading(true);
    setSummary('Analyzing with Gemini...');
    try {
      const logText = logs.join('\n');
      const result = await getGeminiLogSummary(logText);
      setSummary(result);
    } catch (error) {
      console.error("Gemini API error:", error);
      setSummary("Error analyzing logs. Check console for details.");
    } finally {
      setIsSummaryLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatusCard title="System Status" value="Operational" />
        <StatusCard title="Active Jobs" value={isBackupRunning ? '1' : '0'} statusColor={isBackupRunning ? 'text-yellow-400' : 'text-green-400'}/>
        <StatusCard title="Last Backup" value="2h ago" />
        <StatusCard title="Disk Space" value="75% Free" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
            <div className="bg-gray-950/30 p-6 border border-green-500/20 backdrop-blur-sm">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-bold text-white font-orbitron">Live Terminal</h2>
                  <div>
                    <button
                        onClick={handleRunBackup}
                        disabled={isBackupRunning}
                        className="bg-green-900/50 text-green-300 border border-green-500 px-4 py-2 text-sm hover:bg-green-700/50 hover:text-white disabled:bg-gray-700/50 disabled:text-gray-400 disabled:border-gray-600 disabled:cursor-not-allowed transition-all duration-300"
                    >
                        {isBackupRunning ? 'Backup in Progress...' : 'Run Backup Now'}
                    </button>
                  </div>
                </div>
                <LogViewer logs={logs} />
            </div>
        </div>
        <div className="space-y-6">
           <div className="bg-gray-950/30 p-6 border border-green-500/20 backdrop-blur-sm">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-bold text-white font-orbitron">CPU Load</h2>
                </div>
                <div className="h-48">
                    <CpuChart data={cpuData} />
                </div>
            </div>
            <div className="bg-gray-950/30 p-6 border border-green-500/20 backdrop-blur-sm">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-bold text-white font-orbitron">Gemini Log Analysis</h2>
                     <button
                        onClick={handleAnalyzeLogs}
                        disabled={isSummaryLoading}
                        className="bg-purple-900/50 text-purple-300 border border-purple-500 px-3 py-1 text-xs hover:bg-purple-700/50 hover:text-white disabled:bg-gray-700/50 disabled:text-gray-400 disabled:border-gray-600 transition-all duration-300"
                    >
                        {isSummaryLoading ? 'Analyzing...' : 'Analyze'}
                    </button>
                </div>
                <p className="text-sm text-gray-300 h-24 overflow-y-auto">{summary}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
