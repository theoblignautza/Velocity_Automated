#!/usr/bin/env bash

set -Eeuo pipefail

APP_NAME="velocity-backup-sentinel"
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$APP_DIR/installer.log"

exec > >(tee -a "$LOG_FILE") 2>&1

trap 'echo "❌ Error on line $LINENO"; exit 1' ERR

info() { echo "▶ $1"; }
success() { echo "✅ $1"; }

require_non_root() {
  if [ "$EUID" -eq 0 ]; then
    echo "❌ Do NOT run as root."
    exit 1
  fi
}

check_os() {
  case "$OSTYPE" in
    linux*|darwin*) ;;
    *)
      echo "❌ Unsupported OS: $OSTYPE"
      exit 1
      ;;
  esac
}

check_node() {
  command -v node >/dev/null 2>&1 || {
    echo "❌ Node.js missing (v18+ required)"
    exit 1
  }
  command -v npm >/dev/null 2>&1 || {
    echo "❌ npm missing"
    exit 1
  }
}

install_deps() {
  info "Installing dependencies..."
  npm install
  success "Dependencies installed"
}

build_app() {
  info "Building production bundle..."
  npm run build
  success "Build completed"
}

start_app() {
  if [ ! -d "dist" ]; then
    echo "❌ dist/ not found. Build failed or not run."
    exit 1
  fi

  info "Starting production server..."
  npm start
}

uninstall_app() {
  info "Uninstalling application..."

  rm -rf node_modules dist .vite
  rm -f package-lock.json installer.log

  success "Uninstall complete"
}

usage() {
  cat <<EOF

$APP_NAME Installer

Usage:
  ./installer.sh install     Install, build, and start
  ./installer.sh build       Build only
  ./installer.sh start       Start server
  ./installer.sh uninstall   Remove installed files

EOF
}

cd "$APP_DIR"

require_non_root
check_os
check_node

case "${1:-help}" in
  install)
    install_deps
    build_app
    start_app
    ;;
  build)
    build_app
    ;;
  start)
    start_app
    ;;
  uninstall)
    uninstall_app
    ;;
  *)
    usage
    ;;
esac

